//
//  PlanListViewController.swift
//  PlansMap
//
//  Created by Muhammed Demirak on 3/24/22.
//

import UIKit

class PlanListViewController : UICollectionViewController {
    
    /*
    var dataSource : DataSource!                // data source of the list view controller
    let activeUser : User = User.sampleUser
     */
    // plans filtered by date
    /*
    var filteredPlans : [Plan] {
        return activeUser.plans.filter { listStyle.shouldInclude(plan: $0, user: activeUser) }.sorted { $0.startTime < $1.startTime }
    }
    
    // the initial list style used
    var listStyle : PlanListStyle = .all
    // the filter tab
    let listStyleSegmentedControl = UISegmentedControl(items: [
        PlanListStyle.all.name, PlanListStyle.your_plans.name, PlanListStyle.other_plans.name
    ])
    */
    
    // override the viewdidload function
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /*
        let listLayout = listLayout()
        collectionView.collectionViewLayout = listLayout
        */
        // let cellRegistration = UICollectionView.CellRegistration(handler: cellRegHandler)
        
        /*
        dataSource = DataSource(collectionView : collectionView) {
            (collectionView: UICollectionView, indexPath: IndexPath, itemIdentifier: Plan.ID) in
            return collectionView.dequeueConfiguredReusableCell(using: cellRegistration, for: indexPath, item: itemIdentifier)
        }
        */
        /*
        // adding an add button to the nav controller of list controller
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(didPressAddButton(_:)))
        addButton.accessibilityLabel = NSLocalizedString("Add Plan", comment: "Add button accessibility label")
        navigationItem.rightBarButtonItem = addButton
        */
        /*
        listStyleSegmentedControl.selectedSegmentIndex = listStyle.rawValue
        listStyleSegmentedControl.addTarget(self, action: #selector(didChangeListStyle(_:)), for: .valueChanged)
        navigationItem.titleView = listStyleSegmentedControl
        */
        
        /*
        updateSnapshot()
        
        collectionView.dataSource = dataSource
         */
    }
    
    /*
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        let id = activeUser.plans[indexPath.item].id
        showDetail(for: id)
        return false
    }
    
    func showDetail(for id : Plan.ID) {
        var plan = plan(for: id)
        let planDetailViewController = PlanViewController(plan: plan) { [weak self] plan in
            self?.update(plan, with: plan.id)
            self?.updateSnapshot(reloading: [plan.id])
            self?.navigationController?.popViewController(animated: true)
        }
        
        navigationController?.pushViewController(planDetailViewController, animated: true)
    }
     */
    
    /*
    private func listLayout() -> UICollectionViewCompositionalLayout {
        var list_config = UICollectionLayoutListConfiguration(appearance: .grouped)
        list_config.showsSeparators = false
        list_config.trailingSwipeActionsConfigurationProvider = makeSwipeActions
        list_config.backgroundColor = .clear
        return UICollectionViewCompositionalLayout.list(using: list_config)
    }
    
    private func makeSwipeActions(for indexPath: IndexPath?) -> UISwipeActionsConfiguration? {
        guard let indexPath = indexPath, let id = dataSource.itemIdentifier(for: indexPath) else { return nil }
        let deleteActionTitle = NSLocalizedString("Delete", comment: "Delete action title")
        let deleteAction = UIContextualAction(style: .destructive, title: deleteActionTitle) { [weak self] _, _, completion in
            self?.deletePlan(with: id)
            self?.updateSnapshot()
            completion(false)
        }
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
     */
}
