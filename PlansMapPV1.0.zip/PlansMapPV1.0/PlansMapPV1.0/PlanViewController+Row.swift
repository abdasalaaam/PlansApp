//
//  PlanViewController+Row.swift
//  PlansMap
//
//  Created by Muhammed Demirak on 3/25/22.
//

import UIKit

extension PlanViewController {
    
    // rows present in the plan view controller
    enum Row : Hashable {
        case header(String)       // header
        case viewTitle            // title
        case viewDay              // the day
        case viewStartTime        // start time
        case viewEndTime          // end time
        case viewAddress          // address
        case viewNotes            // notes
        case editText(String?)    // editing text
        case editDate(Date)       // editing day and time
        case editTimeDate(Date)   // editing just time
        
        // the type of image icon to use for the corresponding row
        var imageName : String? {
            switch self {
            case .viewDay: return "calendar.circle"
            case .viewStartTime: return "clock"
            case .viewEndTime: return "clock"
            case .viewAddress: return "globe.americas.fill"
            case .viewNotes: return "square.and.pencil"
            default: return nil
            }
        }
        
        // turns icons to the images
        var image: UIImage? {
            guard let imageName = imageName else { return nil }
            let configuration = UIImage.SymbolConfiguration(textStyle: .headline)
            return UIImage(systemName: imageName, withConfiguration: configuration)
        }
        
        // the text style of the row
        var textStyle: UIFont.TextStyle {
            switch self {
                case .viewTitle: return .headline
                default: return .subheadline
            }
        }
    }
    
}
