//
//  ViewController.swift
//  PlansMapPV1.0
//
//  Created by Muhammed Demirak on 4/14/22.
//

import UIKit
import MapKit
import CoreLocation

class PlansViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

