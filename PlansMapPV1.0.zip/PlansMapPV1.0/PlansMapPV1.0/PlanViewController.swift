//
//  PlanViewController.swift
//  PlansMap
//
//  Created by Muhammed Demirak on 3/24/22.
//

import UIKit

// the plan view controller
class PlanViewController : UIViewController {
    
    
    // display the plan view controller
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    
    
    
}

