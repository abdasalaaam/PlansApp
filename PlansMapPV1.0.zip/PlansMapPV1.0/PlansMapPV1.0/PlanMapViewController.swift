//
//  ViewController.swift
//  PlansMap
//
//  Created by Muhammed Demirak on 3/9/22.
//

import UIKit
import MapKit
import CoreLocation

class PlanMapViewController : UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var theMapView: MKMapView!
    
    var locationManager = CLLocationManager()
    
    let activeUser : User = User.sampleUser

    // overriding the viewDidLoad function
    override func viewDidLoad() {
        super.viewDidLoad()

        determineCurrentLocation()
        addMapOverlay()
        theMapView.delegate = self
    }
    
    private func addMapOverlay() {
        for plan in activeUser.plans {
            let planAnnotation : MKPointAnnotation = MKPointAnnotation()
            loc_coord(plan: plan) { (completion, error) in
                if error == nil {
                    planAnnotation.coordinate = CLLocationCoordinate2DMake(completion.latitude, completion.longitude)
                    planAnnotation.title = plan.title
                    planAnnotation.subtitle = "\(plan.day.dayText) \(plan.startTime.timeText) - \(plan.endTime.timeText)"
                    print("plan location: \(planAnnotation.coordinate.latitude) \(planAnnotation.coordinate.longitude)")
                } else {
                    print("error: improper coord")
                }
            }
            theMapView.addAnnotation(planAnnotation)
        }
    }
    
    
    // gets the coordinates of the address
    private func loc_coord(plan: Plan, completionHandler: @escaping (CLLocationCoordinate2D, NSError?) -> Void) {
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(plan.address) { (placemarks, error) in
            if error == nil {
                if let placemark = placemarks?[0] {
                    let location = placemark.location!
                    completionHandler(location.coordinate, nil)
                    return
                }
            }
            completionHandler(kCLLocationCoordinate2DInvalid, error as NSError?)
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // get the current location of the user
        guard let locationValue : CLLocationCoordinate2D = manager.location?.coordinate else { return }
        let initialRegionSpan = MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
        let initialRegion = MKCoordinateRegion(center: locationValue, span: initialRegionSpan)
        
        // display user's current location on the map
        theMapView.setRegion(initialRegion, animated: false)
        
        // place an annotation/pin on the user's location in the map display
        let userPin : MKPointAnnotation = MKPointAnnotation()
        userPin.coordinate = CLLocationCoordinate2DMake(locationValue.latitude, locationValue.longitude)
        userPin.title = "YOU"
        userPin.subtitle = "this is you !"
    
        theMapView.addAnnotation(userPin)
        
        print("location = \(locationValue.latitude) \(locationValue.longitude)")
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: "MyMarker")
        if annotation.title == "YOU" {
            annotationView.markerTintColor = .systemIndigo
            annotationView.glyphImage = UIImage(named: "bmoicon")
        } else {
            //if annotation.subtitle.
            annotationView.markerTintColor = .systemOrange
            annotationView.glyphImage = UIImage(named: "connecticon")
        }
        return annotationView
    }
    
    private func determineCurrentLocation() {
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
    }
    
}
