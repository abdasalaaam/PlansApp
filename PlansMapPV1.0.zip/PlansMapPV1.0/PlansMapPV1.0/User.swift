//
//  User.swift
//  PlansMap
//
//  Created by Muhammed Demirak on 3/9/22.
//

import Foundation

class User : Identifiable {
    public var fullName : String // full title in the format of "(First) (Last)" otherwise error
    public var userName : String
    public var email : String
    private var phone : Int
    private var age : Int
    public var password : String
    public var plans : [Plan] = []
    public var friends : [User] = []
    
    // private var timeZone : TimeZone = TimeZone.autoupdatingCurrent
    // private var calender : Calendar = Calendar.autoupdatingCurrent
    
    init() {
        self.fullName = ""
        self.userName = ""
        self.email = ""
        self.phone = 0
        self.age = 0
        self.password = ""
    }
    
    init(fullName : String, userName : String, email : String, phone : Int, age : Int, password : String) {
        self.fullName = fullName
        self.userName = userName
        self.email = email
        self.phone = phone
        self.age = age
        self.password = password
    }
    
    private init(fullName : String, userName : String, email : String, phone : Int, age : Int, password : String, plans: [Plan]) {
        self.fullName = fullName
        self.userName = userName
        self.email = email
        self.phone = phone
        self.age = age
        self.password = password
        self.plans = plans
    }
    
    private init(fullName : String, userName : String, email : String, phone : Int, age : Int, password : String, friends : [User]) {
        self.fullName = fullName
        self.userName = userName
        self.email = email
        self.phone = phone
        self.age = age
        self.password = password
        self.friends = friends
        for friend in friends {
            for friendPlan in friend.plans {
                self.plans.append(friendPlan)
            }
        }
    }
    
    // adding a plan to the plan list
    func addPlan(_ plan: Plan) -> User {
        for friend in friends {
            plan.attendees?.append(friend)
        }
        plan.setOwner(newOwner: self)
        for friend in friends {
            friend.plans.append(plan)
        }
        plans.append(plan)
        return self
    }
    
    // .equals override in swift
    static func == (lhs: User, rhs: User) -> Bool {
        if (lhs.userName == rhs.userName) {
            return true
        }
        else {
            return false
        }
    }
    
}

#if DEBUG
extension User {
    
    // sample friends
    private static var friend1  = User(fullName: "Jack Torres", userName: "jack", email: "jack@mail.com", phone: 2345678901, age: 21, password: "password123").addPlan(
        Plan(title: "Dinner at Piada",
             startTime: Date().addingTimeInterval(2500.0),
             endTime: Date().addingTimeInterval(5000.0),
             address: "13947 Cedar Rd, South Euclid, OH, 44118",
             notes: "")).addPlan(
        Plan(title: "go to the movies",
            startTime: Date().addingTimeInterval(5000.0),
            endTime: Date().addingTimeInterval(7500.00),
            address: "2163 Lee Rd, Cleveland Heights, OH 44118",
            notes: "drama preferred")).addPlan(
        Plan(title: "clubbin at barley",
             startTime: Date().addingTimeInterval(7000.0),
             endTime: Date().addingTimeInterval(9000.0),
             address: "1261 W 6th St, Cleveland, OH 44113",
             notes: ""))
    private static var friend2  = User(fullName: "Frank Miller", userName: "frankie", email: "frankie@mail.com", phone: 4567890123, age: 21, password: "password123").addPlan(
        Plan(title: "fiji rave",
             startTime: Date().addingTimeInterval(4550.0),
             endTime: Date().addingTimeInterval(6000.0),
             address: "11317 Bellflower Rd, Cleveland, OH, 44106",
             notes: "make sure to register before")).addPlan(
        Plan(title: "BEACH!",
            startTime: Date().addingTimeInterval(18000.0),
            endTime: Date().addingTimeInterval(24000.0),
            address: "Lakewood",
            notes: "bring trunks!"))
    private static var friend3  = User(fullName: "Eddie Johnson", userName: "eddie01", email: "eddie01@mail.com", phone: 5678901234, age: 21, password: "password123").addPlan(
        Plan(title: "Movie Night",
             startTime: Date().addingTimeInterval(24300.0),
             endTime: Date().addingTimeInterval(32300.0),
             address: "SmAprtmt",
             notes: "popcorn needed")).addPlan(
        Plan(title: "Study Sesh",
             startTime: Date().addingTimeInterval(42000),
             endTime: Date().addingTimeInterval(45000),
             address: "library",
             notes: "")).addPlan(
        Plan(title: "To the mall",
             startTime: Date().addingTimeInterval(15100.0),
             endTime: Date().addingTimeInterval(15100.0),
             address: "beachwood mall",
             notes: "the mall"))
    // sample friends list
    private static var sampleFriendList = [friend1, friend2, friend3]
    
    // sample test user with existing plans and existing friends
    static var sampleUser = User(fullName: "John Doe", userName: "johndoe", email: "johndoe@mail.com", phone: 1234567890, age: 21, password: "password123", friends: sampleFriendList).addPlan(
        Plan(title: "Basketball",
             startTime: Date().addingTimeInterval(6800.0),
             endTime: Date().addingTimeInterval(7800),
             address: "ballcourt address",
             notes: "Game Quarter-Finals, be there")).addPlan(
        Plan(title: "Study Sesh",
             startTime: Date().addingTimeInterval(42000),
             endTime: Date().addingTimeInterval(45000),
             address: "library",
             notes: "")).addPlan(
        Plan(title: "To the mall",
             startTime: Date().addingTimeInterval(15100.0),
             endTime: Date().addingTimeInterval(15100.0),
             address: "beachwood mall",
             notes: "the mall"))
}
#endif




