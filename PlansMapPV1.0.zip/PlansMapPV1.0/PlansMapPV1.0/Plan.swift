//
//  Plan.swift
//  PlansMap
//
//  Created by Muhammed Demirak on 3/9/22.
//

import UIKit
import Foundation
import CoreLocation

class Plan : Equatable, Identifiable {
    // Initialization Fields
    public var id : String = UUID().uuidString  // the uniquely generated id of the plan
    public var title : String                    // title of the plan created by the owner
    public var day : Date                       // the day of the plan
    public var startTime : Date                 // the starting time of the plan
    public var endTime : Date                   // the ending time of the plan
    public var address : String!                // the address the plan will be located at
    public var notes : String                   // the details of the plan
    //public var image : UIImage? = nil           // the image of the plan (that may work)
    private var planDateFormatter : DateFormatter = DateFormatter() // a date formatter that may be needed
    
    // User Fields
    public var owner : User! = User()             // the owner of the plan
    public var attendees : [User]! = []       // the users who are attending the plan
                                                // which will all be users
    // Location Fields
    private var loc : CLLocation = CLLocation() // the core location property of the address
    private var street_num : String? = nil      // the street of the address
    private var city : String? = nil            // the city of the address
    private var state : String? = nil           // the state of the address
    private var zip : String? = nil
    
    // Plan Activity fields
    public var isLive : Bool = false            // checks if the plan is live and active (if the start time hits)
    public var isComplete : Bool = false        // checks if the plan is completed (if the end time hits)
    
    // Initializer
    init(title : String, startTime : Date, endTime : Date,
         address : String, notes : String) {
        self.title = title
        self.startTime = startTime
        self.day = startTime
        self.endTime = endTime
        self.address = address
        self.notes =  notes
    }
    
    init(title : String, startTime : Date, endTime : Date,
                 address : String, notes : String, owner : User) {
        self.title = title
        self.startTime = startTime
        self.day = startTime
        self.endTime = endTime
        self.address = address
        self.notes =  notes
        self.owner = owner
    }
    
    
    func setOwner(newOwner : User) {
        self.owner = newOwner
    }
    
    func ownerAssign(newOwner : User) -> Plan {
        self.owner = newOwner
        return self
    }
    
    // .equals override in swift
    static func == (lhs: Plan, rhs: Plan) -> Bool {
        if (lhs.id == rhs.id) {
            return true
        }
        else {
            return false
        }
    }
    
    func isPlanOwner(user: User) -> Bool {
        return user == owner
    }
    
    func planOwner() -> User {
        return owner
    }
    
    // to get a cl-location
    /*
    func loc_addr(completionHandler: @escaping (CLPlacemark?) -> Void) {
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(self.loc) { (placemarks, error) in
            guard error == nil else {
                print("*** Error in \(#function): \(error!.localizedDescription)")
                completionHandler(nil)
                return
            }
                        
            guard let placemark = placemarks?[0] else {
                print("*** Error in \(#function): placemark is nil")
                completionHandler(nil)
                return
            }
            completionHandler(placemark)
        }
    }
    */
}

// array of plans
extension Array where Element == Plan {
    func indexOfPlan(with id: Plan.ID) -> Self.Index {
        guard let index = firstIndex(where: { $0.id == id }) else {
            fatalError()
        }
        return index
    }
}

